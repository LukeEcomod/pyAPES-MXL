# -*- coding: utf-8 -*-
"""
Created on Wed Sep 21 11:14:35 2016

@author: slauniai
"""

#__init__.py

#needed for python to recognize folder as package